<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discuss Project</title>
    <?php include('./client/commonFiles.php'); ?>
    <style>
        /* Background styling */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* Centered welcome message */
        .welcome-message {
            text-align: center;
            padding: 20px;
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }

        /* Container for main content */
        .content {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffffd9;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Category box styling */
        .category-box {
            background-color: #fff;
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            border: 2px solid #ddd; /* Adding a border around each category */
            transition: transform 0.2s ease-in-out;
        }

        .category-box:hover {
            transform: scale(1.02);
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
        }

        /* Category title styling */
        .category-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 8px;
        }

        /* Category description styling */
        .category-description {
            font-size: 14px;
            color: #666;
        }

        /* Specific category styling with unique borders */
        .mobile-category {
            border-color: #4CAF50; /* Green border for Mobile */
        }

        .laptop-category {
            border-color: #2196F3; /* Blue border for Laptop */
        }

        .food-category {
            border-color: #FF9800; /* Orange border for Food */
        }

        .coding-category {
            border-color: #9C27B0; /* Purple border for Coding */
        }

        .general-category {
            border-color: #9E9E9E; /* Grey border for General */
        }
    </style>
</head>
<body>

<?php 
// Start the session only if it hasn't already been started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('./client/header.php');
?>

<!-- Welcome text -->
<div class="welcome-message">
    Welcome to the Discuss Project! Dive into discussions, ask questions, and find answers.
</div>

<!-- Main content container -->
<div class="content">
    <?php
    // Example of how categories might look in questions.php
    // Check if each $_GET key exists before accessing it
    if (isset($_GET['signup']) && !isset($_SESSION['user']['username'])) {
       include('./client/signup.php');

    } else if (isset($_GET['login']) && !isset($_SESSION['user']['username'])) {
       include('./client/login.php');

    } else if (isset($_GET['ask'])) {
       include('./client/ask.php');

    } else if (isset($_GET['q-id'])) {
       $qid = $_GET['q-id'];
       include('./client/question-details.php');

    } else if (isset($_GET['c-id'])) {
       $cid = $_GET['c-id'];
       include('./client/questions.php');

    } else if (isset($_GET['u-id'])) {
       $uid = $_GET['u-id'];
       include('./client/questions.php');

    } else if (isset($_GET['latest'])) {
       include('./client/questions.php');

    } else if (isset($_GET['search'])) {
       $search = $_GET['search'];
       include('./client/questions.php');

    } else {
       include('./client/questions.php');
    }
    ?>
</div>

<!-- Sample category box structure -->
<div class="content">
    <div class="category-box mobile-category">
        <div class="category-title">Mobile</div>
        <div class="category-description">Discuss the latest mobile trends, reviews, and tips.</div>
    </div>
    <div class="category-box laptop-category">
        <div class="category-title">Laptop</div>
        <div class="category-description">Share insights on the newest laptops and tech reviews.</div>
    </div>
    <div class="category-box food-category">
        <div class="category-title">Food</div>
        <div class="category-description">Talk about delicious recipes, food reviews, and trends.</div>
    </div>
    <div class="category-box coding-category">
        <div class="category-title">Coding</div>
        <div class="category-description">Discuss coding techniques, tips, and challenges.</div>
    </div>
    <div class="category-box general-category">
        <div class="category-title">General</div>
        <div class="category-description">A space for general discussions on various topics.</div>
    </div>
</div>

</body>
</html>
