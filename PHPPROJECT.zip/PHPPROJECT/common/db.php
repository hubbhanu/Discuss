<?php
$host = "localhost";
$username = "root"; // Make sure this is the correct username for your MySQL setup
$password = ""; // Use an empty string if there is no password
$database = "discuss";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optionally comment out this line in production to avoid displaying sensitive info
// echo "Database connected"; // Uncomment this for debugging only
?>
