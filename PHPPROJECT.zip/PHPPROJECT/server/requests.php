<?php
session_start();
include("../common/db.php");

if (isset($_POST['signup'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Prepare and execute the insert statement
    $user = $conn->prepare("INSERT INTO `users` (`username`, `email`, `password`, `address`) VALUES (?, ?, ?, ?)");
    $user->bind_param("ssss", $username, $email, $hashed_password, $address);
    $result = $user->execute();
    
    if ($result) {
        $_SESSION["user"] = ["username" => $username, "email" => $email, "user_id" => $user->insert_id];
        header("location: /PHPPROJECT");
        exit(); // Prevent further script execution after redirect
    } else {
        echo "New user not registered";
    }
} elseif (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute the query to find the user
    $query = $conn->prepare("SELECT * FROM users WHERE email=?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION["user"] = ["username" => $row['username'], "email" => $email, "user_id" => $row['id']];
            header("location: /PHPPROJECT");
            exit();
        } else {
            echo "Invalid credentials";
        }
    } else {
        echo "New user not registered";
    }
} elseif (isset($_GET['logout'])) {
    session_unset();
    header("location: /PHPPROJECT");
    exit();
} elseif (isset($_POST["ask"])) {
    // Ensure the user is logged in
    if (!isset($_SESSION['user'])) {
        echo "You must be logged in to ask a question.";
        exit();
    }

    $title = $_POST['title'];
    $description = $_POST['description'];
    $category_id = $_POST['category'];
    $user_id = $_SESSION['user']['user_id'];

    // Prepare and execute the insert statement for the question
    $question = $conn->prepare("INSERT INTO `questions` (`title`, `description`, `category_id`, `user_id`) VALUES (?, ?, ?, ?)");
    $question->bind_param("ssii", $title, $description, $category_id, $user_id);
    $result = $question->execute();

    if ($result) {
        // Redirect to questions page to view submitted questions
        header("location: /PHPPROJECT");
        exit();
    } else {
        echo "Question not added to website";
    }
} elseif (isset($_POST["answer"])) {
    // Ensure the user is logged in
    if (!isset($_SESSION['user'])) {
        echo "You must be logged in to answer a question.";
        exit();
    }

    $answer = $_POST['answer'];
    $question_id = $_POST['question_id'];
    $user_id = $_SESSION['user']['user_id'];

    // Prepare and execute the insert statement for the answer
    $query = $conn->prepare("INSERT INTO `answers` (`answer`, `question_id`, `user_id`) VALUES (?, ?, ?)");
    $query->bind_param("sii", $answer, $question_id, $user_id);
    $result = $query->execute();

    if ($result) {
        // Redirect back to the question details
        header("location: /PHPPROJECT?q-id=$question_id");
        exit();
    } else {
        echo "Answer not submitted";
    }
} elseif (isset($_GET["delete"])) {
    $qid = intval($_GET["delete"]);
    
    // Prepare and execute the delete statement
    $query = $conn->prepare("DELETE FROM questions WHERE id = ?");
    $query->bind_param("i", $qid);
    $result = $query->execute();

    if ($result) {
        // Redirect to the main questions page
        header("location: /PHPPROJECT");
        exit();
    } else {
        echo "Question not deleted";
    }
}
?>
